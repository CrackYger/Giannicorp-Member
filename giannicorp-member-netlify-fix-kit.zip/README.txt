Giannicorp Member – Netlify Fix Kit

1) Kopiere die drei Dateien in dein Repo (Root):
   - src/env.d.ts
   - netlify.toml
   - _redirects

2) Prüfe package.json:
   "scripts": {
     "build": "vite build"
   }
   (Falls aktuell "tsc -b && vite build" drinsteht und TS im CI meckert,
   kannst du zum Testen kurz auf nur "vite build" wechseln.)

3) In Netlify UI (Site Settings → Build & deploy → Environment):
   - VITE_SUPABASE_URL = https://<dein>.supabase.co
   - VITE_SUPABASE_ANON_KEY = <anon-key>
   - (Optional) NODE_VERSION = 20
   - Dann "Clear cache and deploy site".

4) Wenn der Build trotzdem fehlschlägt:
   - Im Log ganz nach oben scrollen und die erste Fehlermeldung kopieren.
   - Häufige Ursachen:
     • @supabase/supabase-js fehlt in dependencies → `npm i @supabase/supabase-js`
     • Tippfehler bei ENV-Variablen (VITE_ Präfix muss vorhanden sein)
     • fehlende Redirects (jetzt durch _redirects abgedeckt)
